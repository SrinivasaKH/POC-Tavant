﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UserData;

namespace WebApiStart.Controllers
{
    public class UserController : ApiController
    {
        public IEnumerable<User> Get()
        {
            using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
            {
                return GEntities.Users.ToList();
            }
        }

        public HttpResponseMessage Get(int id)
        {
            using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
            {
                var entity= GEntities.Users.FirstOrDefault(u => u.Id == id);
                if(entity !=null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound,"Employee With Id =" + id.ToString() + "Not found" );
                }

            }
        }

        public HttpResponseMessage post([FromBody] User user)
        {
            try
            {
                using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
                {
                    GEntities.Users.Add(user);
                    GEntities.SaveChanges();
                    var message = Request.CreateResponse(HttpStatusCode.Created, user);
                    message.Headers.Location = new Uri(Request.RequestUri + user.Id.ToString());
                    return message;
                }
            }
           catch(Exception ex)
            {
               return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


        [HttpDelete]
        public HttpResponseMessage delete_userid(int id)
        {
            try
            {
                using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
                {
                    var entity = GEntities.Users.FirstOrDefault(u => u.Id == id);
                    if (entity == null)
                    {
                        //return Request.CreateResponse(HttpStatusCode.OK, entity);
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee With Id =" + id.ToString() + "Not found");
                    }
                    else
                    {
                        // return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee With Id =" + id.ToString() + "Not found");
                        GEntities.Users.Remove(entity);
                        GEntities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK, entity);
                    }

                }
            }
            catch(Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
           
        }

        [HttpPut]
        public HttpResponseMessage Update_user(int id, [FromBody]User user )
        {
            try
            {
                using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
                {
                    var userID = GEntities.Users.FirstOrDefault(u => u.Id == id);
                    if (userID == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee ID =" + id.ToString() + "Not Found");
                    }
                    else
                    {
                        userID.UserName = user.UserName;
                        userID.FullName = user.FullName;
                        userID.EmailID = user.EmailID;
                        GEntities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK, userID);
                    }
                }
            }
            catch(Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
            
        }
    }
}
