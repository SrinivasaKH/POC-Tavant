﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UserData;

namespace WebApiStart.Controllers
{
    public class AppUserController : ApiController
    {
        public IEnumerable<UsersApp> Get()
        {
            using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
            {
                return GEntities.UsersApps.ToList();
            }
        }

      

        public HttpResponseMessage Get(int id)
        {
            using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
            {
                var entity = GEntities.UsersApps.FirstOrDefault(u => u.EmployeeID == id);
                if (entity != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee With Id =" + id.ToString() + "Not found");
                }

            }
        }


        public HttpResponseMessage post([FromBody] UsersApp usersApp)
        {
            try
            {
               
                using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
                {
                    GEntities.UsersApps.Add(usersApp);
                    GEntities.SaveChanges();
                    var message = Request.CreateResponse(HttpStatusCode.Created, usersApp);
                    message.Headers.Location = new Uri(Request.RequestUri + usersApp.EmployeeID.ToString());
                    return message;
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


      //  [HttpPut]
        public HttpResponseMessage Put(int id, [FromBody] UsersApp usersApp)
        {
            try
            {
                using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
                {
                    var userID = GEntities.UsersApps.FirstOrDefault(u => u.EmployeeID == id);
                    if (userID == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee ID =" + id.ToString() + "Not Found");
                    }
                    else
                    {

                        userID.name = usersApp.name;
                        userID.designation = usersApp.designation;
                        userID.skills = usersApp.skills;
                        userID.Years = usersApp.Years;
                        userID.Training = usersApp.Training;
                        GEntities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK, userID);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }

        }




        public HttpResponseMessage Delete(int id)
        {
            try
            {
                using (GYMONEDBMVCEntities GEntities = new GYMONEDBMVCEntities())
                {
                    var entity = GEntities.UsersApps.FirstOrDefault(u => u.EmployeeID == id);
                    if (entity == null)
                    {
                        //return Request.CreateResponse(HttpStatusCode.OK, entity);
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee With Id =" + id.ToString() + "Not found");
                    }
                    else
                    {
                        // return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee With Id =" + id.ToString() + "Not found");
                        GEntities.UsersApps.Remove(entity);
                        GEntities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK, entity);
                    }

                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }

        }


    }
}
