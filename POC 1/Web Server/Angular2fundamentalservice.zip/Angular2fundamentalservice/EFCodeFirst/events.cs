﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirst
{
    public class events
    {
        public events()
        {
        }

        [Key]
        [Column(Order = 0)]
        public int ID { get; set; }
        [StringLength(50)]
        public string EvenName { get; set; }
        public DateTime EventDate { get; set; }
        [Column(Order = 3)]
        [StringLength(50)]
        public string EventTime { get; set; }
        public double EventPrice { get; set; }
        [StringLength(50)]
        public string EventLocation { get; set; }
        [StringLength(50)]
        public string EventCity { get; set; }
        [StringLength(50)]
        public string EventCountry { get; set; }
        [StringLength(100)]
        public string OnlineUrl { get; set; }
        [StringLength(100)]
        public string ImageUrl { get; set; }



    }
}
