namespace EFCodeFirst
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class AngulaTwofundamentalModel : DbContext
    {
        public AngulaTwofundamentalModel()
            //: base("name=AngulaTwofundamentalModel")
        {
        }

        //public virtual DbSet<Regdetail> Regdetails { get; set; }
        //public virtual DbSet<Login> Login { get; set; }
        //public virtual DbSet<Duration> Duration { get; set; }
        //public virtual DbSet<Timeduration> Timeduration { get; set; }


        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Regdetail>()
        //        .Property(e => e.Name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Regdetail>()
        //        .Property(e => e.Email)
        //        .IsFixedLength();
        //}
    }
}
