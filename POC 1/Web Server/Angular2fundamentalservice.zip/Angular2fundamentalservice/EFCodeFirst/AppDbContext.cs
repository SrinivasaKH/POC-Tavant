﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirst
{
    public class AppDbContext : DbContext
    {
        public AppDbContext() : base("AngulaTwofundamentalModel")
        {

        }

        public DbSet<Login> Logins { get; set; }
        public DbSet<Duration> Duration { get; set; }
        public DbSet<Timeduration> Timeduration { get; set; }
        public DbSet<levels> Level { get; set; }
        public DbSet<Session> Session { get; set; }
        public DbSet<events> Events { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Regdetail>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Regdetail>()
                .Property(e => e.Email)
                .IsFixedLength();

            Database.SetInitializer<AppDbContext>(null);
            base.OnModelCreating(modelBuilder);
        }

    }
  
}
