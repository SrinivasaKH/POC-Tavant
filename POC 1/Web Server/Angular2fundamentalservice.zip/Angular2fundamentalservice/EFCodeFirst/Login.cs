﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirst
{
    public class Login
    {

        public Login()
        {

        }
        [Key]
        [System.ComponentModel.DataAnnotations.Schema.Column(Order = 0)]
        public int LoginID { get; set; }

        [StringLength(10)]
        public string UserName { get; set; }
        [StringLength(10)]
        public string passWord { get; set; }
        public int Islocked { get; set; }
        public int Attemptcount { get; set; }
        public Nullable<DateTime> LockedTime { get; set;}


    }

}
