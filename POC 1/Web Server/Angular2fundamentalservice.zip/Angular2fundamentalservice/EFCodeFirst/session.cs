﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirst
{
    public class Session
    {
        [Key]
        [Column(Order = 0)]
        public int ID { get; set; }
        [Column(Order = 1)]
        public  int EID { get; set;}
        [StringLength(50)]
        public string SessionName { get; set; }
        [StringLength(50)]
        public string Presenter { get; set; }
        [StringLength(50)]
        public string Duration { get; set;}
        [StringLength(50)]
        public string Level { get; set; }
        [StringLength(500)]
        public string Absstrct { get; set; }



    }
}
