﻿using EFCodeFirst;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Web.Http;
using EFCodeFirst;
using System.Runtime.Caching;
using System.Collections;

namespace Angular2fundamentalservice.Controllers
{
    public class AuthenticationController : ApiController
    {
        public Models.LoginModel cmodel = new Models.LoginModel();


        public const string CacheKey = "UserNameStocks";
        public MemoryCache cache = new MemoryCache("CachingProvider");


        [HttpPost]
        [ActionName("LoginCtrl")]
        public IHttpActionResult Login(Models.LoginModel model)
        {


            if (model == null)
            {
                return BadRequest("Please enter valid data.");
            }
            AppDbContext db = new AppDbContext();


            //    var user = db.Logins.Where(x => x.UserName == model.Username && x.passWord == model.Password).SingleOrDefault();+

            var user = db.Logins.Where(x => x.UserName == model.Username).SingleOrDefault();
            if (user == null)
            {
                int count = 0;
                count = count + 1;
                return Ok(false);
            }
            else if (user.passWord != model.Password)
            {
                cmodel.Username = model.Username;
                return Ok(false);

            }
            else
            {
                var userlogin = db.Logins.Where(x => x.UserName == model.Username && x.passWord == model.Password).SingleOrDefault();
                return Ok(new { name = model.Username });
            }

            //  return Ok(new { name = model.Username, email = model.Username });

            //return Ok(new { name = model.Username});

        }

        [HttpPost]
        [ActionName("NewLoginUser")]
        public IHttpActionResult Addnewuserlogin([FromBody] Models.LoginModel model)
        {
            AppDbContext db = new AppDbContext();
            bool newuser = db.Logins.Where(u => u.UserName == model.Username).Any();
            if (newuser)
            {
                return BadRequest("User Name already exist.");

            }
            else
            {

                db.Logins.Add(new EFCodeFirst.Login() { UserName = model.Username, passWord = model.Password });
                db.SaveChanges();
                return Ok("inserted");
            }

        }

        [HttpGet]
        [ActionName("Getdurations")]
        public IHttpActionResult Getdurations()
        {
            AppDbContext db = new AppDbContext();
            //var durations = db.Timedurationlists.ToList();
            var durations = db.Duration.ToList();
            //var durations= from duration in db.Durations select duration;
            return Ok(new { durations });
        }

        [HttpGet]
        [ActionName("Getlevels")]
        public IHttpActionResult Getlevels()
        {
            AppDbContext db = new AppDbContext();
            var levels = db.Level.ToList();
            return Ok(new { levels });
        }

        [HttpPost]
        [ActionName("AddNewEvent")]
        public IHttpActionResult AddNewEvent([FromBody] Models.EventModel eventmodel)
        {
            AppDbContext db = new AppDbContext();
            db.Events.Add(new EFCodeFirst.events()
            {
                EvenName = eventmodel.name,
                EventDate = eventmodel.date,
                EventPrice = eventmodel.price,
                EventLocation = eventmodel.location.address,
                EventCity = eventmodel.location.city,
                EventCountry = eventmodel.location.country,
                OnlineUrl = eventmodel.onlineurl,
                ImageUrl = eventmodel.ImageUrl
            });
            db.SaveChanges();
            return Ok();
        }

        [HttpPost]
        [ActionName("AddNewSession")]
        public IHttpActionResult AddNewSession([FromBody] Models.SessionModel seesionmodel)
        {
            AppDbContext db = new AppDbContext();
          //  var EventId =  db.Events.OrderByDescending(x=> x.ID).First();
            int EventId = (from Id in db.Events select Id.ID).Max();
            //  int EventId = Convert.ToInt16(Id);
            db.Session.Add(new EFCodeFirst.Session()
            {
                EID = EventId,
                SessionName = seesionmodel.name,
                Presenter = seesionmodel.presenter,
                Duration = seesionmodel.duration.ToString(),
                Level = seesionmodel.level,
                Absstrct = seesionmodel.abstracts

            });
            db.SaveChanges();
            return Ok();
        }



    }
}
