﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Angular2fundamentalservice.Models
{
    public class LocationModel
    {
        public string address { get; set; }
        public string city { get; set; }
        public string country { get; set; }
    }
}