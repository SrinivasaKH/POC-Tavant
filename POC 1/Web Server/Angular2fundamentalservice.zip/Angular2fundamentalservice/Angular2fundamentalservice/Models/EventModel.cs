﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Angular2fundamentalservice.Models
{
    public class EventModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public DateTime date { get; set; }
        public string time { get; set; }
        public Double price { get; set; }
        public string imageUrl { get; set; }
        public string country { get; set; }
        public string onlineurl { get; set; }
        public string ImageUrl { get; set; } 

        public LocationModel location { get; set; }

    } }





    