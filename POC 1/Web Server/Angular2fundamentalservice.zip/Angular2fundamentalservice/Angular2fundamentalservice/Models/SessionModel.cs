﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Angular2fundamentalservice.Models
{
    public class SessionModel
    {
        public string name { get; set; }
        public string presenter { get; set; }
        public string duration { get; set; }
        public string level { get; set; }
        public string abstracts { get; set; }
   
    }
}